function out = randi(max_value,M,N)

% out = randi(max_value,M,N) returns an M-by-N matrix containing pseudorandom
%     integer values drawn from the discrete uniform distribution ranging
%     from 1 to max_value.
%     
% this function intentionally re-create the Matlab randi function. It is designed
% for those with older version of matlab which doesn't have this function
%     
%  Cyril Pernet 31/01/2014

out = ceil(rand(M,N).*max_value);